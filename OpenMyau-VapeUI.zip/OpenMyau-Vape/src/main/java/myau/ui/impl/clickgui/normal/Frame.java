package myau.ui.impl.clickgui.normal;

import lombok.Getter;
import myau.module.Module;
import myau.ui.impl.clickgui.normal.component.Component;
import myau.ui.impl.clickgui.normal.component.ModuleEntry;
import myau.util.RenderUtil;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Vape v4-style panel frame.
 * Flat dark header, plain text category name, simple list of modules below.
 * No rounded corners, no drop shadows, no animations on the panel itself.
 */
public class Frame extends Component {
    private static final int HEADER_HEIGHT_PX = 12;  // tight header like Vape

    private final String categoryName;
    private final ArrayList<ModuleEntry> moduleEntries;
    private int dragX, dragY;
    private boolean dragging;
    private boolean expanded;
    @Getter
    private float currentHeight;

    public Frame(String categoryName, List<Module> modules, int x, int y, int width, int height) {
        super(x, y, width, HEADER_HEIGHT_PX);
        this.categoryName = categoryName;
        this.dragging = false;
        this.expanded = true;
        this.moduleEntries = new ArrayList<>();
        this.currentHeight = HEADER_HEIGHT_PX;
        for (Module module : modules) {
            this.moduleEntries.add(new ModuleEntry(module, x, 0, width, 11));
        }
    }

    public boolean isAnyComponentBinding() {
        if (expanded) {
            for (ModuleEntry entry : moduleEntries) {
                if (entry.isBinding()) return true;
            }
        }
        return false;
    }

    @Override
    public void render(int mouseX, int mouseY, float partialTicks, float animationProgress, boolean isLast, int scrollOffset, float deltaTime) {
        int alpha = (int) (255 * animationProgress);
        if (alpha < 5) return;

        int scrolledY = y - scrollOffset;

        // ── Header ───────────────────────────────────────────────
        int headerBg = MaterialTheme.getRGBWithAlpha(MaterialTheme.HEADER_BG, alpha);
        RenderUtil.drawRect(x, scrolledY, x + width, scrolledY + HEADER_HEIGHT_PX, headerBg);

        // Category name: white, minecraft font, left-padded 3px, centred vertically
        String header = categoryName + (expanded ? " -" : " +");
        int textColor = MaterialTheme.getRGBWithAlpha(MaterialTheme.TEXT_ENABLED, alpha);
        mc.fontRendererObj.drawString(header, x + 3, scrolledY + (HEADER_HEIGHT_PX - 8) / 2, textColor, false);

        // ── Module list ──────────────────────────────────────────
        float listHeight = 0;
        for (ModuleEntry entry : moduleEntries) listHeight += entry.getCurrentHeight();
        this.currentHeight = expanded ? (HEADER_HEIGHT_PX + listHeight) : HEADER_HEIGHT_PX;

        if (expanded) {
            // Panel body background
            int panelBg = MaterialTheme.getRGBWithAlpha(MaterialTheme.PANEL_BG, alpha);
            RenderUtil.drawRect(x, scrolledY + HEADER_HEIGHT_PX, x + width, scrolledY + HEADER_HEIGHT_PX + (int) listHeight, panelBg);

            RenderUtil.scissor(x, scrolledY + HEADER_HEIGHT_PX, width, (int) listHeight);
            int currentModuleY = y + HEADER_HEIGHT_PX;
            for (int i = 0; i < moduleEntries.size(); i++) {
                ModuleEntry entry = moduleEntries.get(i);
                entry.setX(x);
                entry.setY(currentModuleY);
                entry.setWidth(width);
                entry.render(mouseX, mouseY, partialTicks, animationProgress, i == moduleEntries.size() - 1, scrollOffset, deltaTime);
                currentModuleY += (int) entry.getCurrentHeight();
            }
            RenderUtil.releaseScissor();
        }

        // Bottom border line
        int sepColor = MaterialTheme.getRGBWithAlpha(MaterialTheme.SEPARATOR, alpha);
        RenderUtil.drawRect(x, scrolledY + (int) currentHeight - 1, x + width, scrolledY + (int) currentHeight, sepColor);
    }

    @Override
    public void render(int mouseX, int mouseY, float partialTicks, float animationProgress, boolean isLast, int scrollOffset) {
        render(mouseX, mouseY, partialTicks, animationProgress, isLast, scrollOffset, 0.016f);
    }

    @Override
    public boolean mouseClicked(int mouseX, int mouseY, int mouseButton) {
        return mouseClicked(mouseX, mouseY, mouseButton, 0);
    }

    @Override
    public boolean mouseClicked(int mouseX, int mouseY, int mouseButton, int scrollOffset) {
        if (isMouseOverHeader(mouseX, mouseY, scrollOffset)) {
            if (mouseButton == 0) {
                this.dragging = true;
                this.dragX = mouseX - this.x;
                this.dragY = mouseY - this.y;
                return true;
            } else if (mouseButton == 1) {
                expanded = !expanded;
                return true;
            }
        }
        if (expanded) {
            if (currentHeight <= HEADER_HEIGHT_PX) return false;
            for (ModuleEntry entry : moduleEntries) {
                if (entry.mouseClicked(mouseX, mouseY, mouseButton, scrollOffset)) return true;
            }
        }
        return false;
    }

    public boolean isMouseOverHeader(int mouseX, int mouseY, int scrollOffset) {
        int actualY = this.y - scrollOffset;
        return mouseX >= x && mouseX <= x + width && mouseY >= actualY && mouseY <= actualY + HEADER_HEIGHT_PX;
    }

    @Override
    public void mouseReleased(int mouseX, int mouseY, int mouseButton) {
        mouseReleased(mouseX, mouseY, mouseButton, 0);
    }

    @Override
    public void mouseReleased(int mouseX, int mouseY, int mouseButton, int scrollOffset) {
        this.dragging = false;
        if (expanded) {
            for (ModuleEntry entry : moduleEntries) {
                entry.mouseReleased(mouseX, mouseY, mouseButton, scrollOffset);
            }
        }
    }

    public void updatePosition(int mouseX, int mouseY) {
        if (this.dragging) {
            this.x = mouseX - this.dragX;
            this.y = mouseY - this.dragY;
        }
    }

    @Override
    public void keyTyped(char typedChar, int keyCode) {
        if (expanded) {
            for (ModuleEntry entry : moduleEntries) {
                entry.keyTyped(typedChar, keyCode);
            }
        }
    }
}
