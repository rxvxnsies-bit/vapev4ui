package myau.ui.impl.clickgui.normal;

import java.awt.*;

/**
 * Vape v4-style flat dark theme.
 * No rounded corners, no gradients, no shadows.
 */
public class MaterialTheme {
    // Panel background: near-black with slight transparency
    public static final Color PANEL_BG         = new Color(20, 20, 20, 210);
    // Header background: slightly lighter strip
    public static final Color HEADER_BG        = new Color(30, 30, 30, 230);
    // Enabled module text color (white, like Vape)
    public static final Color TEXT_ENABLED     = new Color(255, 255, 255);
    // Disabled module text color (dark grey)
    public static final Color TEXT_DISABLED    = new Color(130, 130, 130);
    // Settings text / secondary
    public static final Color TEXT_COLOR_SECONDARY = new Color(150, 150, 150);
    // Accent for sliders / active elements (Vape uses white; we match)
    public static final Color PRIMARY_COLOR    = new Color(255, 255, 255);
    // Thin separator line colour
    public static final Color SEPARATOR        = new Color(50, 50, 50, 180);

    // No rounded corners – this is the Vape aesthetic
    public static final float CORNER_RADIUS_FRAME = 0.0f;

    // Keep legacy aliases so other files compile without changes
    public static final Color SURFACE_CONTAINER_HIGH = new Color(40, 40, 40, 200);
    public static final Color TEXT_COLOR              = TEXT_ENABLED;
    public static final Color OUTLINE_COLOR           = SEPARATOR;

    public static int getRGB(Color color) {
        return color.getRGB();
    }

    public static int getRGBWithAlpha(Color color, int alpha) {
        alpha = Math.max(0, Math.min(255, alpha));
        return new Color(color.getRed(), color.getGreen(), color.getBlue(), alpha).getRGB();
    }
}
