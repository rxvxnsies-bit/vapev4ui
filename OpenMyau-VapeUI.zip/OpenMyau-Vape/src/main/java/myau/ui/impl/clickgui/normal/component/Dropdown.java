package myau.ui.impl.clickgui.normal.component;

import lombok.Getter;
import myau.property.properties.ModeProperty;

import java.awt.*;
import java.util.Arrays;
import java.util.List;

/** Vape-style dropdown: current value in header, options listed below on expand. */
public class Dropdown extends Component {
    private static final int ITEM_H = 11;
    @Getter private final ModeProperty modeProperty;
    private final int headerHeight;
    private boolean expanded;

    public Dropdown(ModeProperty modeProperty, int x, int y, int width, int height) {
        super(x, y, width, height);
        this.modeProperty = modeProperty;
        this.headerHeight = height;
    }

    @Override
    public int getHeight() {
        List<String> modes = Arrays.asList(modeProperty.getValuePrompt().split(", "));
        return expanded ? headerHeight + modes.size() * ITEM_H : headerHeight;
    }

    @Override
    public void render(int mouseX, int mouseY, float partialTicks, float animationProgress, boolean isLast, int scrollOffset, float deltaTime) {
        if (!modeProperty.isVisible()) return;
        int alpha = (int)(255 * animationProgress);
        if (alpha < 5) return;

        int scrolledY = y - scrollOffset;
        int textCol = new Color(200, 200, 200, alpha).getRGB();
        mc.fontRendererObj.drawString(modeProperty.getName() + ": " + modeProperty.getModeString(),
                x + 1, scrolledY + (headerHeight - 8) / 2, textCol, false);

        if (expanded) {
            List<String> modes = Arrays.asList(modeProperty.getValuePrompt().split(", "));
            for (int i = 0; i < modes.size(); i++) {
                int itemY = scrolledY + headerHeight + i * ITEM_H;
                boolean hov = mouseX >= x && mouseX <= x + width && mouseY >= itemY && mouseY < itemY + ITEM_H;
                int col = hov
                        ? new Color(255, 255, 255, alpha).getRGB()
                        : new Color(160, 160, 160, alpha).getRGB();
                mc.fontRendererObj.drawString("  " + modes.get(i), x + 1, itemY + (ITEM_H - 8) / 2, col, false);
            }
        }
    }

    @Override public boolean mouseClicked(int mouseX, int mouseY, int mouseButton) { return false; }
    @Override
    public boolean mouseClicked(int mouseX, int mouseY, int mouseButton, int scrollOffset) {
        int sy = y - scrollOffset;
        if (mouseX >= x && mouseX <= x + width && mouseY >= sy && mouseY <= sy + headerHeight) {
            expanded = !expanded; return true;
        }
        if (expanded) {
            List<String> modes = Arrays.asList(modeProperty.getValuePrompt().split(", "));
            for (int i = 0; i < modes.size(); i++) {
                int itemY = sy + headerHeight + i * ITEM_H;
                if (mouseX >= x && mouseX <= x + width && mouseY >= itemY && mouseY < itemY + ITEM_H) {
                    modeProperty.setValue(i); expanded = false; return true;
                }
            }
        }
        return false;
    }
    @Override public void mouseReleased(int mouseX, int mouseY, int mouseButton) {}
    @Override public void keyTyped(char typedChar, int keyCode) {}
}
