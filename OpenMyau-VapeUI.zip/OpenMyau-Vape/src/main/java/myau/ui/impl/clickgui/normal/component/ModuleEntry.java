package myau.ui.impl.clickgui.normal.component;

import lombok.Getter;
import myau.Myau;
import myau.module.Module;
import myau.property.Property;
import myau.property.properties.*;
import myau.ui.impl.clickgui.normal.MaterialTheme;
import myau.util.RenderUtil;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Vape v4-style module row.
 * Enabled = bright white text. Disabled = grey text.
 * No hover effects, no glow, no animated dot — just text.
 * Settings expand below the entry when right-clicked, plain Minecraft-font rows.
 */
public class ModuleEntry extends Component {
    private static final int ENTRY_HEIGHT = 11;  // tight row height like Vape

    @Getter
    private final Module module;
    private final List<Component> propertiesComponents;
    private boolean expanded;
    private float currentSettingsHeight = 0f;

    public ModuleEntry(Module module, int x, int y, int width, int height) {
        super(x, y, width, ENTRY_HEIGHT);
        this.module = module;
        this.expanded = false;
        this.propertiesComponents = new ArrayList<>();
        initializePropertiesComponents();
    }

    private void initializePropertiesComponents() {
        KeybindComponent keybindComp = new KeybindComponent(module, x, y + ENTRY_HEIGHT, width, 11);
        propertiesComponents.add(keybindComp);

        if (Myau.propertyManager != null) {
            List<Property<?>> properties = Myau.propertyManager.properties.get(module.getClass());
            if (properties != null) {
                for (Property<?> property : properties) {
                    Component comp = null;
                    if (property instanceof BooleanProperty) {
                        comp = new Switch((BooleanProperty) property, x, 0, width, 11);
                    } else if (property instanceof IntProperty || property instanceof FloatProperty || property instanceof PercentProperty) {
                        comp = new Slider(property, x, 0, width, 18);
                    } else if (property instanceof ModeProperty) {
                        comp = new Dropdown((ModeProperty) property, x, 0, width, 11);
                    } else if (property instanceof ColorProperty) {
                        comp = new ColorPicker((ColorProperty) property, x, 0, width, 50);
                    } else if (property instanceof TextProperty) {
                        comp = new TextField((TextProperty) property, x, 0, width, 11);
                    }
                    if (comp != null) propertiesComponents.add(comp);
                }
            }
        }
    }

    private boolean isComponentVisible(Component comp) {
        if (comp instanceof Switch)      return ((Switch)      comp).getProperty().isVisible();
        if (comp instanceof Slider)      return ((Slider)      comp).getProperty().isVisible();
        if (comp instanceof Dropdown)    return ((Dropdown)    comp).getProperty().isVisible();
        if (comp instanceof ColorPicker) return ((ColorPicker) comp).getProperty().isVisible();
        if (comp instanceof TextField)   return ((TextField)   comp).getProperty().isVisible();
        return true;
    }

    @Override
    public void render(int mouseX, int mouseY, float partialTicks, float animationProgress, boolean isLast, int scrollOffset, float deltaTime) {
        int alpha = (int) (255 * animationProgress);
        if (alpha < 5) return;

        int scrolledY = y - scrollOffset;

        // Subtle hover highlight (very faint, Vape-like)
        if (isMouseOverHeader(mouseX, mouseY, scrollOffset)) {
            RenderUtil.drawRect(x, scrolledY, x + width, scrolledY + ENTRY_HEIGHT,
                    new Color(255, 255, 255, (int)(18 * animationProgress)).getRGB());
        }

        // Module text: white = enabled, grey = disabled
        Color textCol = module.isEnabled() ? MaterialTheme.TEXT_ENABLED : MaterialTheme.TEXT_DISABLED;
        int finalTextColor = MaterialTheme.getRGBWithAlpha(textCol, alpha);
        mc.fontRendererObj.drawString(module.getName(), x + 3, scrolledY + (ENTRY_HEIGHT - 8) / 2, finalTextColor, false);

        // ── Settings panel ───────────────────────────────────────
        float visibleHeightSum = 0;
        if (expanded) {
            for (Component comp : propertiesComponents) {
                if (isComponentVisible(comp)) visibleHeightSum += comp.getHeight();
            }
        }

        // Simple instant expand (no animation = Vape feel)
        this.currentSettingsHeight = visibleHeightSum;

        if (currentSettingsHeight > 0) {
            // Slightly lighter background for settings area
            RenderUtil.drawRect(x, scrolledY + ENTRY_HEIGHT,
                    x + width, scrolledY + ENTRY_HEIGHT + (int) currentSettingsHeight,
                    new Color(35, 35, 35, (int)(200 * animationProgress)).getRGB());

            RenderUtil.scissor(x, scrolledY + ENTRY_HEIGHT, width, (int) currentSettingsHeight);
            float dynY = y + ENTRY_HEIGHT;
            for (Component comp : propertiesComponents) {
                if (!isComponentVisible(comp)) continue;
                comp.setX(x + 3);
                comp.setY((int) dynY);
                comp.setWidth(width - 6);
                comp.render(mouseX, mouseY, partialTicks, animationProgress, false, scrollOffset, deltaTime);
                dynY += comp.getHeight();
            }
            RenderUtil.releaseScissor();
        }
    }

    public float getCurrentHeight() {
        return ENTRY_HEIGHT + currentSettingsHeight;
    }

    private boolean isMouseOverHeader(int mouseX, int mouseY, int scrollOffset) {
        int actualY = this.y - scrollOffset;
        return mouseX >= x && mouseX <= x + width && mouseY >= actualY && mouseY <= actualY + ENTRY_HEIGHT;
    }

    @Override
    public boolean mouseClicked(int mouseX, int mouseY, int mouseButton) { return false; }

    @Override
    public boolean mouseClicked(int mouseX, int mouseY, int mouseButton, int scrollOffset) {
        if (isMouseOverHeader(mouseX, mouseY, scrollOffset)) {
            if (mouseButton == 0) { module.toggle(); return true; }
            if (mouseButton == 1) {
                if (!propertiesComponents.isEmpty()) expanded = !expanded;
                return true;
            }
        }
        if (expanded && currentSettingsHeight >= 5) {
            for (Component comp : propertiesComponents) {
                if (!isComponentVisible(comp)) continue;
                if (comp.mouseClicked(mouseX, mouseY, mouseButton, scrollOffset)) return true;
            }
        }
        return false;
    }

    public boolean isBinding() {
        if (expanded) {
            for (Component comp : propertiesComponents) {
                if (!isComponentVisible(comp)) continue;
                if (comp instanceof KeybindComponent && ((KeybindComponent) comp).isBinding()) return true;
            }
        }
        return false;
    }

    @Override
    public void keyTyped(char typedChar, int keyCode) {
        if (expanded) {
            for (Component comp : propertiesComponents) {
                if (isComponentVisible(comp)) comp.keyTyped(typedChar, keyCode);
            }
        }
    }

    @Override
    public void mouseReleased(int mouseX, int mouseY, int mouseButton) {}

    @Override
    public void mouseReleased(int mouseX, int mouseY, int mouseButton, int scrollOffset) {
        if (expanded) {
            for (Component comp : propertiesComponents) {
                if (isComponentVisible(comp)) comp.mouseReleased(mouseX, mouseY, mouseButton, scrollOffset);
            }
        }
    }
}
