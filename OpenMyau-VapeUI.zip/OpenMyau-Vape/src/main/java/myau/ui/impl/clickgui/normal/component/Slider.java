package myau.ui.impl.clickgui.normal.component;

import lombok.Getter;
import myau.property.Property;
import myau.property.properties.FloatProperty;
import myau.property.properties.IntProperty;
import myau.property.properties.PercentProperty;
import myau.util.RenderUtil;
import org.lwjgl.input.Mouse;

import java.awt.*;
import java.math.BigDecimal;
import java.math.RoundingMode;

/** Vape-style slider: label + value on one line, thin flat track beneath. */
public class Slider extends Component {
    @Getter private final Property property;
    private final double min, max, step;
    private boolean dragging;

    public Slider(Property property, int x, int y, int width, int height) {
        super(x, y, width, height);
        this.property = property;
        if (property instanceof IntProperty) {
            this.min = ((IntProperty) property).getMinimum();
            this.max = ((IntProperty) property).getMaximum();
            this.step = 1.0;
        } else if (property instanceof PercentProperty) {
            this.min = 0; this.max = 100; this.step = 1.0;
        } else {
            this.min = ((FloatProperty) property).getMinimum();
            this.max = ((FloatProperty) property).getMaximum();
            this.step = 0.05;
        }
    }

    @Override
    public void render(int mouseX, int mouseY, float partialTicks, float animationProgress, boolean isLast, int scrollOffset, float deltaTime) {
        if (!property.isVisible()) return;
        if (dragging) {
            if (Mouse.isButtonDown(0)) updateSliderValue(mouseX);
            else dragging = false;
        }

        double value, min, max;
        if (property instanceof IntProperty) {
            min = ((IntProperty) property).getMinimum(); max = ((IntProperty) property).getMaximum();
            value = (Integer) property.getValue();
        } else if (property instanceof PercentProperty) {
            min = 0; max = 100; value = (Integer) property.getValue();
        } else {
            min = ((FloatProperty) property).getMinimum(); max = ((FloatProperty) property).getMaximum();
            value = (Float) property.getValue();
        }

        double fill = (max - min != 0) ? Math.max(0, Math.min(1, (value - min) / (max - min))) : 0;

        int scrolledY = y - scrollOffset;
        int alpha = (int)(255 * animationProgress);
        if (alpha < 5) return;

        // Label left, value right – Minecraft default font
        String label = property.getName();
        String valStr = round(value) + (property instanceof PercentProperty ? "%" : "");
        int textCol = new Color(200, 200, 200, alpha).getRGB();
        mc.fontRendererObj.drawString(label,  x + 1, scrolledY + 1, textCol, false);
        mc.fontRendererObj.drawString(valStr, x + width - mc.fontRendererObj.getStringWidth(valStr) - 1, scrolledY + 1, textCol, false);

        // Flat track
        int trackY = scrolledY + height - 5;
        int trackW = width - 2;
        RenderUtil.drawRect(x + 1, trackY, x + 1 + trackW, trackY + 3, new Color(50, 50, 50, alpha).getRGB());
        int fillW = (int)(trackW * fill);
        if (fillW > 0)
            RenderUtil.drawRect(x + 1, trackY, x + 1 + fillW, trackY + 3, new Color(200, 200, 200, alpha).getRGB());
    }

    private void updateSliderValue(int mouseX) {
        double progress = Math.max(0, Math.min(1, (mouseX - (x + 1)) / (double)(width - 2)));
        double newValue = min + (max - min) * progress;
        if (property instanceof IntProperty || property instanceof PercentProperty) {
            property.setValue((int) Math.round(newValue));
        } else {
            newValue = Math.round(newValue / step) * step;
            BigDecimal bd = new BigDecimal(newValue).setScale(2, RoundingMode.HALF_UP);
            property.setValue((float) Math.max(min, Math.min(max, bd.doubleValue())));
        }
    }

    private double round(double value) {
        return new BigDecimal(value).setScale(2, RoundingMode.HALF_UP).doubleValue();
    }

    @Override public boolean mouseClicked(int mouseX, int mouseY, int mouseButton) { return false; }
    @Override
    public boolean mouseClicked(int mouseX, int mouseY, int mouseButton, int scrollOffset) {
        int sy = y - scrollOffset;
        if (mouseButton == 0 && mouseX >= x && mouseX <= x + width && mouseY >= sy + height - 8 && mouseY <= sy + height) {
            dragging = true; updateSliderValue(mouseX); return true;
        }
        return false;
    }
    @Override public void mouseReleased(int mouseX, int mouseY, int mouseButton) { dragging = false; }
    @Override public void mouseReleased(int mouseX, int mouseY, int mouseButton, int scrollOffset) { dragging = false; }
    @Override public void keyTyped(char typedChar, int keyCode) {}
}
