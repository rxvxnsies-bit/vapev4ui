package myau.ui.impl.clickgui.normal.component;

import myau.property.properties.BooleanProperty;

import java.awt.*;

/** Vape-style boolean: just text, colour indicates state. No toggle widget. */
public class Switch extends Component {
    private final BooleanProperty booleanProperty;

    public Switch(BooleanProperty booleanProperty, int x, int y, int width, int height) {
        super(x, y, width, height);
        this.booleanProperty = booleanProperty;
    }

    public BooleanProperty getProperty() { return booleanProperty; }

    @Override
    public void render(int mouseX, int mouseY, float partialTicks, float animationProgress, boolean isLast, int scrollOffset, float deltaTime) {
        if (!booleanProperty.isVisible()) return;
        int alpha = (int)(255 * animationProgress);
        if (alpha < 5) return;
        int scrolledY = y - scrollOffset;
        boolean val = booleanProperty.getValue();
        int col = val
                ? new Color(255, 255, 255, alpha).getRGB()
                : new Color(130, 130, 130, alpha).getRGB();
        mc.fontRendererObj.drawString(booleanProperty.getName() + ": " + (val ? "on" : "off"),
                x + 1, scrolledY + (height - 8) / 2, col, false);
    }

    @Override public boolean mouseClicked(int mouseX, int mouseY, int mouseButton) { return false; }
    @Override
    public boolean mouseClicked(int mouseX, int mouseY, int mouseButton, int scrollOffset) {
        int sy = y - scrollOffset;
        if (mouseX >= x && mouseX <= x + width && mouseY >= sy && mouseY <= sy + height) {
            booleanProperty.setValue(!booleanProperty.getValue()); return true;
        }
        return false;
    }
    @Override public void mouseReleased(int mouseX, int mouseY, int mouseButton) {}
    @Override public void keyTyped(char typedChar, int keyCode) {}
}
